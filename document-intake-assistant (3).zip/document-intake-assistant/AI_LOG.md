# AI log

Built end-to-end in a single session with Claude (Anthropic), working
directly in a sandboxed dev environment (not copy-pasting between a chat
window and an editor) — so what follows is a candid account of the actual
back-and-forth, not a tidied-up retelling.

## Key prompts / direction given

- Initial framing: "build this to the brief, optimize for speed since the
  deadline is tomorrow, pick the stack yourself." I deferred stack choice
  entirely to Claude and only specified: no build step for the frontend
  (plain HTML/JS, not React) — the brief doesn't reward a bundler, and it
  keeps "straightforward local setup" honest. FastAPI backend because
  Pydantic gives free schema validation, which maps directly onto the
  brief's "define an explicit schema" requirement instead of hand-rolling
  one.
- Explicit instruction to make the LLM interaction provider-agnostic
  rather than hard-coding one vendor, since the brief calls out "you may
  use any LLM provider" and separately allows a mock/stub if API access
  isn't available. This shaped the whole `LLMClient` abstraction —
  wasn't an afterthought, was requested up front.
- Asked for the model to never be allowed to write directly into
  application state — every model response goes through an explicit
  validation boundary first. This is the single biggest engineering
  decision in the codebase (`extraction.py`) and was a direct requirement
  from the brief's "validate model output before applying it," not
  something I had to prompt twice for.

## Design decisions I made (not just accepted)

- **Two-call-free design**: the LLM does extraction *and* phrases the next
  question in one call, but *which field to ask next* is decided by
  deterministic Python (`IntakeState.next_missing_required_field`), not by
  the model. I pushed for this explicitly after the first draft had the
  model deciding conversation flow — it's more testable and it's the part
  of the brief ("avoid repeatedly asking for information already
  captured") that's easiest to get subtly wrong if you leave it to the
  model's judgement turn to turn.
- Chose to represent "unknown" (`None`) and "unconfirmed / ambiguous"
  (`needs_clarification` dict) as genuinely different states rather than
  overloading `None` for both, because the brief explicitly separates
  "missing," "unclear," and "contradictory" as three different cases the
  app needs to handle differently.

## Output I questioned or corrected

- First draft of `document_generator.py` returned from Claude used a
  generic "some information is still missing" placeholder instead of
  naming *which* fields were still outstanding. I asked for the
  `needs_clarification` map to be surfaced explicitly in the rendered
  document — a document that just says "some fields missing" isn't
  actually useful to review against.
- The Pydantic model initially raised `PydanticUserError` on `REQUIRED_FIELDS`
  because a plain class-level list on a `BaseModel` gets treated as a
  field needing a type annotation. Caught by actually running the test
  suite rather than trusting the code looked right — fixed with
  `ClassVar[list[str]]`. Small, but a good reminder that "the code reads
  correctly" and "the code runs" aren't the same claim.
- Similarly, a test-import bug (`from conftest import ...` instead of
  `from tests.conftest import ...`) only surfaced when pytest was actually
  run — left in on purpose here as evidence the test suite was executed,
  not just written and assumed to pass.
- Pushed back on an early version of the mock LLM client that tried to do
  "smart" multi-field extraction with regex — decided it was worth being
  honest that a keyword stub can't really do that well, and moved the
  burden of proving multi-field handling onto the fixture-driven tests
  (`valid_multi_field.json`) instead of pretending the mock is a real NLU
  system. Documented this trade-off explicitly in the README rather than
  leaving it to be discovered.

## What I'd still want a second pass on

- The system prompt for the real (OpenAI) provider hasn't been tested
  against an actual API key in this session — the contract is exercised
  thoroughly via fixtures, but real model phrasing/edge cases (e.g. a
  model that ignores the "one question at a time" instruction) are
  untested against a live model.
- Haven't load-tested or tried genuinely adversarial input (e.g. a user
  message that tries to get the assistant to claim the document *is*
  legally binding).

## Second pass: contradiction handling, adversarial cases, a real bug

Went back in after comparing against another candidate's submission
(reviewed, not copied from). Two decisions came out of that:

- Their contradiction handling was a genuine strength I didn't have:
  relying on the model to self-report a contradiction (`status:
  "clarify"`) is fragile if the model just doesn't notice. Added a
  deterministic backstop in `extraction.validate_updates` that compares
  every incoming value against current state *and* against other updates
  in the same message, independent of what the model says about itself.
  Chose not to copy their approach (a ~700-line rule-based intent
  classifier) — the same guarantee fits in about 60 lines because the
  check only needs to run at the validation boundary that already exists,
  not duplicate NLU.
- Added `test_adversarial.py` — five cases modelling prompt-injection-style
  input ("ignore previous instructions...", a model that claims
  completion with no evidence, a fake field trying to grant itself
  correction status). All pass by construction, not by luck: the
  architecture already only trusts an allow-listed field contract, never
  the model's own narration of what it did.

Ran a real conversation end to end (not a scripted test) to generate
evidence for `TEST_EVIDENCE.md`, and it found an actual bug: once the 7
core required fields were filled, nothing ever asked about
`specific_gifts` / `additional_wishes` again — the app just looped asking
the same question with no field target. Root cause:
`next_missing_required_field()` only knows about the required set, and
nothing else in `conversation.py` picked up after it. Fixed with
`IntakeState.next_outstanding_field()` (required, then gifts, then
wishes) and two `*_addressed` flags so "not yet asked" and "asked, answer
was none" don't collapse into the same falsy value. Left the discovery
process in `TEST_EVIDENCE.md` rather than quietly fixing it and
pretending the first live run was clean.

Explicitly decided against: a multi-provider model bake-off, prompt/
temperature sweeps, and a Playwright+screenshot evidence pipeline. All
were considered (see the conversation this was built in) and rejected as
disproportionate to a 9-field toy form on a next-day deadline — the
brief asks for judgment, not an ML evaluation research project.
