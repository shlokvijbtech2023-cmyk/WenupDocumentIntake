from __future__ import annotations

import os
import uuid

from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from .conversation import process_turn
from .document_generator import generate_document
from .llm import get_llm_client
from .models import SessionData, Turn

app = FastAPI(title="Document Intake Assistant")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # demo scope only -- see README for production notes
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory store: fine for a take-home demo, called out explicitly in the
# README as the first thing to replace for production (Redis/DB, per the
# session, with TTL and persistence across restarts).
_SESSIONS: dict[str, SessionData] = {}
_LLM = get_llm_client()

OPENING_MESSAGE = (
    "Hi, I'll help you put together a draft Personal Wishes Document. "
    "This is a fictional exercise, not legal advice. Let's start -- "
    "what's your full name?"
)


class CreateSessionResponse(BaseModel):
    session_id: str
    assistant_message: str
    state: dict


class MessageRequest(BaseModel):
    message: str


class MessageResponse(BaseModel):
    assistant_message: str
    state: dict
    document: str
    core_complete: bool
    applied_fields: list[str]
    clarifications: list[str]
    llm_provider_used: str


def _get_session(session_id: str) -> SessionData:
    session = _SESSIONS.get(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Unknown session_id")
    return session


@app.get("/api/health")
def health() -> dict:
    provider = os.environ.get("LLM_PROVIDER", "mock")
    return {"status": "ok", "llm_provider": provider}


@app.post("/api/session", response_model=CreateSessionResponse)
def create_session() -> CreateSessionResponse:
    session_id = str(uuid.uuid4())
    session = SessionData(session_id=session_id)
    session.history.append(Turn(role="assistant", content=OPENING_MESSAGE))
    _SESSIONS[session_id] = session
    return CreateSessionResponse(
        session_id=session_id,
        assistant_message=OPENING_MESSAGE,
        state=session.state.summary_dict(),
    )


@app.post("/api/session/{session_id}/message", response_model=MessageResponse)
def post_message(session_id: str, body: MessageRequest) -> MessageResponse:
    session = _get_session(session_id)
    if not body.message or not body.message.strip():
        raise HTTPException(status_code=400, detail="message must not be empty")

    result = process_turn(session, body.message.strip(), _LLM)

    document = generate_document(session.state)
    if session.state.is_core_complete():
        session.document_generated = True

    return MessageResponse(
        assistant_message=result["assistant_message"],
        state=session.state.summary_dict(),
        document=document,
        core_complete=session.state.is_core_complete(),
        applied_fields=result.get("applied", []),
        clarifications=result.get("clarifications", []),
        llm_provider_used=result.get("llm_provider_used", "primary"),
    )


@app.get("/api/session/{session_id}/state")
def get_state(session_id: str) -> dict:
    session = _get_session(session_id)
    return session.state.summary_dict()


@app.get("/api/session/{session_id}/document")
def get_document(session_id: str) -> dict:
    session = _get_session(session_id)
    return {"document": generate_document(session.state)}


# Serve the plain HTML/JS frontend from the same process, so `uvicorn
# app.main:app` is the only command needed for local setup. Mounted last
# so it never shadows the /api/* routes above.
_FRONTEND_DIR = Path(__file__).resolve().parent.parent.parent / "frontend"
if _FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=str(_FRONTEND_DIR), html=True), name="frontend")
