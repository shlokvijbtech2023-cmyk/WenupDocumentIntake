# Document Intake Assistant

A small conversational app that interviews a user and drafts a **fictional**
Personal Wishes Document. Built for the WenUp engineering technical test.

This is not legal software and the generated document is not legal advice.

## Quick start (no API key required)

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # optional but recommended
pip install -r requirements.txt
cp .env.example .env                                  # LLM_PROVIDER=mock by default
uvicorn app.main:app --reload
```

Open **http://localhost:8000** — the backend also serves the frontend, so
that's the only command you need. `LLM_PROVIDER=mock` runs on a deterministic
local stub with no network calls and no API key.

## Using a real LLM provider

```bash
# in backend/.env
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini   # optional, this is the default
```

Restart the server. If `OPENAI_API_KEY` is missing, the app logs nothing
scary and falls back to the mock provider rather than crashing on startup.

## Running tests

```bash
cd backend
pip install -r requirements.txt
pytest -q
```

48 tests, all offline (no network, no API key needed) — they run against a
`ScriptedLLMClient` fed from fixture files under `backend/tests/fixtures/`
covering valid, ambiguous/contradictory, corrected, malformed, and
adversarial/prompt-injection model responses (`test_adversarial.py`). See
[`TEST_EVIDENCE.md`](./TEST_EVIDENCE.md) for actual pytest output and a
real end-to-end conversation transcript — including a real bug that
run found and the fix for it. See "How the mock/fixtures work" below for why this is the
primary test strategy rather than mocking the OpenAI SDK directly.

## Architecture

```
frontend/            plain HTML/CSS/JS, no build step, no framework
  index.html          two-pane layout: chat | structured state + draft document
  app.js               fetch calls to the backend JSON API; renders state as returned
  style.css

backend/app/
  models.py            IntakeState: the structured schema, the single source of truth
  extraction.py         contract for what the LLM is allowed to say, + validation
  llm.py                LLMClient interface; OpenAIClient + MockLLMClient behind it
  conversation.py       process_turn(): extract -> validate -> merge -> next question
  document_generator.py deterministic templating from IntakeState (no LLM call)
  main.py               FastAPI routes, in-memory session store, API contract

backend/tests/
  fixtures/             valid / ambiguous / corrected / malformed model responses (JSON)
  test_*.py             unit tests per layer + one integration test file (test_api.py)
```

**Separation of concerns**, top to bottom of a single turn:

1. **UI** (`app.js`) only ever sends the user's raw text and renders
   whatever `state` and `document` the backend returns. It never computes
   or infers state itself.
2. **LLM interaction** (`llm.py`) is the only place that talks to a model
   provider. It returns raw (possibly malformed) JSON — it does not
   validate or trust its own output.
3. **Validation** (`extraction.py`) is the boundary: every field name is
   checked against an allow-list, every type is checked, every boolean is
   normalized. Anything that fails is *rejected*, not coerced into a
   guess, and never reaches state.
4. **Application logic** (`conversation.py`) decides, in plain
   deterministic Python, which field to ask about next — the model
   phrases the question, but doesn't decide the interview's flow. This is
   what stops the app from re-asking a question it already has an answer
   to, or wandering off-script.
5. **Document generation** (`document_generator.py`) is template code, not
   a model call — it can only render facts already present in
   `IntakeState`, so it structurally cannot invent anything.

### Structured state as the source of truth

`IntakeState` (in `models.py`) is the explicit schema described in the
brief. A field being `None` means "not yet known"; a field being present
but flagged in `needs_clarification` means "the user said *something*, but
it was ambiguous or contradictory, and we're not treating it as settled."
Conversation history is kept (for the model's context on the next turn)
but the app itself never re-derives facts from it — every read of "what do
we know" goes through `IntakeState`.

### Handling ambiguity, contradictions, and multi-field answers

- The model is instructed to report a field with `"status": "clarify"`
  instead of guessing when an answer is unclear (see the `ambiguous_response`
  fixture and `test_conversation.py::test_ambiguous_response_flags_clarification...`).
  A clarified field blocks the interview from being marked complete until
  it's resolved, and shows up as an "outstanding item" in the draft
  document rather than being silently dropped.
- Corrections are just ordinary `"status": "set"` updates on a field that
  already has a value — the app overwrites rather than appends. There is
  no separate "correction mode": the same code path that fills a blank
  field updates a previously-confirmed one.
- **Contradiction handling does not rely on the model cooperating.**
  `extraction.validate_updates` independently compares every incoming
  value against the current confirmed state (and against other updates in
  the *same* message, so "I have no children, my children are Alice and
  Bob" is caught even though nothing has touched state yet). A conflicting
  value is held back and flagged in `needs_clarification` unless the model
  explicitly marks the update `is_correction: true`. This is deliberately
  a backstop, not the primary mechanism — the model is also asked to
  self-report ambiguity via `status: "clarify"` — because a backstop that
  depends entirely on the thing it's guarding against isn't much of one.
- Multi-field answers ("My name is Jane Smith and I don't have kids") are
  handled because extraction always processes the whole message and can
  return multiple `updates` in a single call — order doesn't matter,
  `conversation.py` applies each in turn.

### Model-error and malformed-output handling

- **Automatic fallback.** When `LLM_PROVIDER` is `openai` or `gemini`,
  every call is wrapped in `FallbackLLMClient`: if the live provider
  errors for any reason (bad/expired key, rate limit, network outage),
  that same turn is silently retried on the deterministic mock instead of
  stalling the conversation. The response is tagged `llm_provider_used`
  (`primary` or `mock_fallback`) so this is never hidden from the API
  consumer. See `TEST_EVIDENCE.md` §6 for a real provider outage caught
  and handled this way, live.
- A failed provider call (network/auth/rate-limit) is caught in `llm.py`
  and surfaced as `{"_error": ...}`; `conversation.py` leaves state
  untouched and tells the user to retry, rather than crashing the request
  or silently losing their last answer.
- Provider output that isn't valid JSON (e.g. wrapped in a ` ```json `
  fence, which real models do despite instructions) is recovered with a
  best-effort regex extraction in `_safe_json_loads`; genuinely unusable
  text falls back to `{"updates": [], "_error": "malformed_json"}`.
- Well-formed JSON with the wrong *shape* (e.g. `updates` is a string, not
  a list) is caught by Pydantic validation in
  `extraction.parse_extraction_result`, and the user is asked to rephrase
  rather than the app 500-ing.
- Well-formed JSON with an unknown field name or a wrong-typed value (a
  model hallucinating a field, or saying `"has_children": "definitely
  maybe"`) is caught one layer deeper, in `validate_updates`, and that
  single field is dropped — the rest of a multi-field update still
  applies. See `malformed_bad_field.json` and its tests.

## API contract

| Method | Path                              | Purpose                                   |
|--------|------------------------------------|--------------------------------------------|
| GET    | `/api/health`                     | provider status check                      |
| POST   | `/api/session`                    | start a session, returns `session_id` + opening message |
| POST   | `/api/session/{id}/message`       | send a user message, returns assistant reply, latest `state`, rendered `document`, `core_complete` |
| GET    | `/api/session/{id}/state`         | latest structured state                    |
| GET    | `/api/session/{id}/document`      | latest rendered draft document             |

Full request/response models are in `backend/app/main.py`
(`MessageRequest`/`MessageResponse` etc.) and enforced by FastAPI/Pydantic,
so the contract is checked, not just documented.

## How the mock/fixtures work

`MockLLMClient` is a small deterministic stub (keyword/yes-no matching, no
real NLU) that drives the whole app offline. It's intentionally simple —
its job is to prove the *interface* (`LLMClient.extract`) works end to end
without a network dependency, not to simulate a good conversational model.
The interesting behaviour (multi-field extraction, ambiguity, corrections,
malformed-JSON recovery) is exercised in the test suite via
`ScriptedLLMClient`, which plays back fixed fixture responses — this is
more useful for testing than the mock itself, since fixtures can represent
*exactly* the awkward cases (a model returning an unknown field, a
non-JSON response) that a keyword stub wouldn't naturally produce.

**Swapping in a different real provider** (e.g. Anthropic): implement
`LLMClient` in `llm.py` with an `extract(history, state, next_field) ->
dict` method that returns the same JSON shape (`{"updates": [...],
"assistant_message": "..."}`), and add a branch for it in
`get_llm_client()`. Nothing else in the app needs to change — `main.py`
and `conversation.py` only depend on the `LLMClient` interface.

## What I'd improve for production

- **Persistence.** Sessions are an in-memory dict — they vanish on
  restart and won't work across multiple server instances. Swap for
  Redis (session TTL, cheap) or a real DB (if the interview needs to be
  resumable/auditable long-term).
- **Auth & rate limiting.** There's currently no user auth or per-user
  rate limiting on `/api/session/*` — fine for a demo, not for anything
  public.
- **Streaming responses.** The assistant reply currently comes back as
  one blocking call; a production chat UI would stream tokens.
- **Better ambiguity handling.** Right now a "clarify" flag just blocks
  completion and shows up as a note; a production version might re-ask
  more intelligently, or offer multiple-choice disambiguation instead of
  open text.
- **Prompt-injection hardening.** The user's free text goes straight into
  the model prompt. For a real legal-adjacent product I'd add stricter
  system-prompt isolation and adversarial testing (e.g. a user trying to
  get the model to claim it *is* giving legal advice).
- **Real NLU for the offline mode**, if offline usage were a real
  requirement rather than a fallback — the current mock is deliberately
  minimal.
- **Structured logging/observability** around model calls: latency,
  rejection rates per field, how often clarification is triggered — useful
  signal for prompt iteration that isn't captured at all right now.
- **CORS** is wide open (`allow_origins=["*"]`) for local demo
  convenience; would lock this to a specific frontend origin.

## AI log

See [`AI_LOG.md`](./AI_LOG.md).
