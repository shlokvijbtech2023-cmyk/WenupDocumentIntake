// Document Intake Assistant -- frontend
// No build step, no framework: plain fetch calls against the FastAPI
// backend's JSON API. State always comes back from the server on every
// turn (the frontend never invents or locally patches structured state),
// which keeps the preview pane a true reflection of the backend's source
// of truth.

// Relative by default: works out of the box when the backend serves this
// frontend directly (the standard setup, see README). Override with
// window.DIA_API_BASE if you're serving the frontend separately.
const API_BASE = window.DIA_API_BASE || "";

const els = {
  status: document.getElementById("connection-status"),
  chatLog: document.getElementById("chat-log"),
  chatForm: document.getElementById("chat-form"),
  chatInput: document.getElementById("chat-input"),
  sendBtn: document.getElementById("send-btn"),
  stateGrid: document.getElementById("state-grid"),
  documentText: document.getElementById("document-text"),
  tabBtns: document.querySelectorAll(".tab-btn"),
  panelState: document.getElementById("panel-state"),
  panelDocument: document.getElementById("panel-document"),
};

const FIELD_LABELS = {
  full_name: "Full name",
  home_address: "Home address",
  covers_worldwide_assets: "Covers worldwide assets",
  has_children: "Has children",
  children_names: "Children's names",
  "executor.name": "Executor name",
  "executor.relationship": "Executor relationship",
  specific_gifts: "Specific gifts",
  additional_wishes: "Additional wishes",
};

let sessionId = null;

function addMessage(role, content) {
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  div.textContent = content;
  els.chatLog.appendChild(div);
  els.chatLog.scrollTop = els.chatLog.scrollHeight;
}

function addSystemNote(text) {
  const div = document.createElement("div");
  div.className = "msg system";
  div.textContent = text;
  els.chatLog.appendChild(div);
  els.chatLog.scrollTop = els.chatLog.scrollHeight;
}

function formatValue(value) {
  if (value === null || value === undefined || value === "") return null;
  if (Array.isArray(value)) return value.length ? value.join(", ") : null;
  if (typeof value === "boolean") return value ? "Yes" : "No";
  return String(value);
}

function renderState(state) {
  els.stateGrid.innerHTML = "";
  const flagged = state.needs_clarification || {};

  const rows = [
    ["full_name", state.full_name],
    ["home_address", state.home_address],
    ["covers_worldwide_assets", state.covers_worldwide_assets],
    ["has_children", state.has_children],
    ["children_names", state.children_names],
    ["executor.name", state.executor?.name],
    ["executor.relationship", state.executor?.relationship],
    ["specific_gifts", state.specific_gifts],
    ["additional_wishes", state.additional_wishes],
  ];

  for (const [field, rawValue] of rows) {
    const wrapper = document.createElement("div");
    wrapper.className = "state-row" + (flagged[field] ? " flagged" : "");

    const dt = document.createElement("dt");
    dt.textContent = FIELD_LABELS[field] || field;

    const dd = document.createElement("dd");
    const formatted = formatValue(rawValue);
    if (formatted) {
      dd.textContent = formatted;
    } else {
      dd.textContent = flagged[field] ? `needs clarification -- ${flagged[field]}` : "not yet provided";
      dd.className = "empty";
    }

    wrapper.appendChild(dt);
    wrapper.appendChild(dd);
    els.stateGrid.appendChild(wrapper);
  }
}

function renderDocument(doc) {
  els.documentText.textContent = doc;
}

function setStatus(text, kind) {
  els.status.textContent = text;
  els.status.className = kind ? `ready ${kind}`.trim() : "";
  if (kind) els.status.classList.add(kind);
}

function setInputEnabled(enabled) {
  els.chatInput.disabled = !enabled;
  els.sendBtn.disabled = !enabled;
}

async function startSession() {
  setStatus("connecting…");
  try {
    const res = await fetch(`${API_BASE}/api/session`, { method: "POST" });
    if (!res.ok) throw new Error(`status ${res.status}`);
    const data = await res.json();
    sessionId = data.session_id;
    addMessage("assistant", data.assistant_message);
    renderState(data.state);
    setStatus("connected", "ready");
    setInputEnabled(true);
    els.chatInput.focus();
  } catch (err) {
    setStatus("offline -- start the backend", "error");
    addSystemNote(
      "Couldn't reach the backend API. Make sure it's running " +
      `(see README) and reachable at ${API_BASE}.`
    );
  }
}

async function sendMessage(message) {
  addMessage("user", message);
  setInputEnabled(false);

  try {
    const res = await fetch(`${API_BASE}/api/session/${sessionId}/message`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });

    if (!res.ok) {
      const detail = await res.json().catch(() => ({}));
      addSystemNote(`Request failed: ${detail.detail || res.status}`);
      return;
    }

    const data = await res.json();
    addMessage("assistant", data.assistant_message);
    renderState(data.state);
    renderDocument(data.document);

    if (data.core_complete) {
      addSystemNote("All core fields captured -- the draft document is ready. You can still add gifts, wishes, or corrections.");
    }
  } catch (err) {
    addSystemNote("Network error -- please try sending that again.");
  } finally {
    setInputEnabled(true);
    els.chatInput.focus();
  }
}

els.chatForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const value = els.chatInput.value.trim();
  if (!value || !sessionId) return;
  els.chatInput.value = "";
  sendMessage(value);
});

els.tabBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    els.tabBtns.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    const tab = btn.dataset.tab;
    els.panelState.hidden = tab !== "state";
    els.panelDocument.hidden = tab !== "document";
  });
});

renderState({ executor: {} });
startSession();
